cat << EOF
<!DOCTYPE html>
<html>
<head>
	<title>My Web Page</title>
</head>
<body>
	<h1>Welcome to my web page!</h1>
	<p>This is a simple HTML page.</p>
</body>
</html>
EOF
